# Solar House Android App

## इस शुरुआती वर्जन में
- Dashboard
- Solar generation estimate calculator
- Customer records (फोन में लोकल सेव)
- AMC / service module का शुरुआती स्क्रीन

## मोबाइल से APK बनाने का तरीका
1. GitHub पर नया repository बनाएं: `solar-house-android`
2. इस ZIP को extract करें और सभी files/folders repository में upload करें.
3. GitHub में Actions tab खोलें.
4. `Build Solar House APK` workflow चुनें और `Run workflow` दबाएं.
5. Build पूरा होने पर workflow run खोलें.
6. नीचे Artifacts में `Solar-House-debug-APK` डाउनलोड करें.
7. ZIP खोलकर `app-debug.apk` अपने Android फोन में इंस्टॉल करें.

## जरूरी बातें
- यह पहला starter build है, production release नहीं.
- Customer records अभी उसी फोन में locally save होते हैं; cloud backup/login नहीं है.
- Calculator एक अनुमान देता है, engineering design या generation guarantee नहीं.
- Play Store पर डालने के लिए बाद में signed release build, privacy policy, store listing और Google Play developer registration की जरूरत होगी.
