package com.solarhouse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SolarHouseApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolarHouseApp() {
    val tabs = listOf("Home", "Calculator", "Customers", "Services")
    var selected by remember { mutableIntStateOf(0) }
    val customers = remember { mutableStateListOf<String>() }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var kw by remember { mutableStateOf("10") }
    var units by remember { mutableStateOf("4") }
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(Unit) {
        val saved = context.getSharedPreferences("solar_house", 0).getString("customers", "[]") ?: "[]"
        val arr = JSONArray(saved)
        for (i in 0 until arr.length()) customers.add(arr.getString(i))
    }
    fun saveCustomers() {
        val arr = JSONArray()
        customers.forEach { arr.put(it) }
        context.getSharedPreferences("solar_house", 0).edit().putString("customers", arr.toString()).apply()
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF16834A), secondary = androidx.compose.ui.graphics.Color(0xFF78B94A))) {
        Scaffold(
            topBar = { TopAppBar(title = { Column {
                Text("SOLAR HOUSE", fontWeight = FontWeight.Bold)
                Text("Solar Business Management", style = MaterialTheme.typography.labelSmall)
            } }) },
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { index, title ->
                        val icon = when(index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Calculate; 2 -> Icons.Default.People; else -> Icons.Default.Build }
                        NavigationBarItem(selected == index, onClick = { selected = index }, icon = { Icon(icon, null) }, label = { Text(title) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                when(selected) {
                    0 -> {
                        Text("Welcome to Solar House", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Industrial & Commercial Solar Solutions", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard("Customers", customers.size.toString(), Modifier.weight(1f))
                            MetricCard("Quick Tools", "4", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Business tools", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        listOf("Solar plant sizing", "Customer records", "AMC & maintenance", "Net metering checklist").forEach {
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.SolarPower, null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.width(12.dp)); Text(it)
                                }
                            }
                        }
                    }
                    1 -> {
                        Text("Solar Generation Calculator", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(kw, { kw = it }, label = { Text("Plant capacity (kW)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(units, { units = it }, label = { Text("Average units per kW per day") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                        val daily = (kw.toDoubleOrNull() ?: 0.0) * (units.toDoubleOrNull() ?: 0.0)
                        val monthly = daily * 30
                        Card(Modifier.fillMaxWidth().padding(top = 16.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Estimated daily generation", style = MaterialTheme.typography.labelLarge)
                                Text("%.1f units".format(daily), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                Text("Estimated monthly: %.0f units".format(monthly))
                                Text("Estimate only; actual output depends on location, season, shading and system losses.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    2 -> {
                        Text("Customer Management", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(name, { name = it }, label = { Text("Customer name") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(phone, { phone = it }, label = { Text("Mobile number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (name.isNotBlank()) {
                                customers.add("$name • ${phone.ifBlank { "No phone" }}")
                                name = ""; phone = ""; saveCustomers()
                            }
                        }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Save customer") }
                        Spacer(Modifier.height(12.dp))
                        Text("Saved customers: ${customers.size}", fontWeight = FontWeight.SemiBold)
                        LazyColumn { items(customers) { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Person, null); Spacer(Modifier.width(10.dp)); Text(item, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { customers.remove(item); saveCustomers() }) { Icon(Icons.Default.Delete, "Delete") }
                                }
                            }
                        } }
                    }
                    3 -> {
                        Text("AMC & Service Records", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Service tracking module is ready for the next build.", modifier = Modifier.padding(top = 8.dp))
                        Card(Modifier.fillMaxWidth().padding(top = 16.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Next features", fontWeight = FontWeight.Bold)
                                Text("• AMC due-date reminders\n• Complaint register\n• Inverter service history\n• Net-metering document checklist")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}
